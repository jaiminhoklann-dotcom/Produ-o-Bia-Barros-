/* Complemento para Produção Bia Barros: copiar descrição das listas. */
(() => {
  function install() {
    document.querySelectorAll('.note-checklist .note-card .note-body').forEach(body => {
      if (body.nextElementSibling?.classList.contains('copy-note-text')) return;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'copy-note-text';
      btn.textContent = '📋 Copiar texto';
      btn.style.cssText = 'display:block;margin:12px 0;padding:10px 16px;border:1px solid #80502c;border-radius:12px;background:#352419;color:#ffc18a;font:inherit;font-weight:600;cursor:pointer';
      btn.addEventListener('click', async () => {
        const value = body.innerText;
        try {
          if (!navigator.clipboard?.writeText) throw new Error('fallback');
          await navigator.clipboard.writeText(value);
        } catch (_) {
          const field = document.createElement('textarea');
          field.value = value;
          field.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
          document.body.append(field);
          field.focus(); field.select(); field.setSelectionRange(0, value.length);
          let ok = false;
          try { ok = document.execCommand('copy'); } catch (_) {} finally { field.remove(); }
          if (!ok) { window.prompt('Copie o texto abaixo:', value); return; }
        }
        btn.textContent = '✓ Texto copiado!';
        setTimeout(() => { btn.textContent = '📋 Copiar texto'; }, 1800);
      });
      body.after(btn);
    });
  }
  function start() {
    install();
    new MutationObserver(install).observe(document.body, {childList:true,subtree:true});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
})();
